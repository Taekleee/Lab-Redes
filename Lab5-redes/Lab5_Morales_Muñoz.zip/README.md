# Lab5-redes
Modulación ask
Versión de python: 3.7.3

Para ejecutar: 

python3 lab5.py

Por consola se muestran los resultados de salida de cada uno de los casos analizados